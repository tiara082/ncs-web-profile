<!-- Header Partial (Navbar + Hero for Home) -->
@include('partials.navbar')
@include('partials.hero-home')
