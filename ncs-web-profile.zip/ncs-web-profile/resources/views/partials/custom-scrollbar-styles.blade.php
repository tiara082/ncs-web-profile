<style>
/* Custom Scrollbar Styles */
::-webkit-scrollbar {
    width: 10px;
}
::-webkit-scrollbar-track {
    background: #f1f1f1;
}
::-webkit-scrollbar-thumb {
    background: #66bbf2;
    border-radius: 5px;
}
::-webkit-scrollbar-thumb:hover {
    background: #222f7f;
}
</style>
