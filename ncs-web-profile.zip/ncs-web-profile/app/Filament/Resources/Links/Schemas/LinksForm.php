<?php

namespace App\Filament\Resources\Links\Schemas;

use Filament\Schemas\Schema;

class LinksForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
