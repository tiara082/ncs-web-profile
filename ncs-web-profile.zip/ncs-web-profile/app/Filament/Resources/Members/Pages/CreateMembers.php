<?php

namespace App\Filament\Resources\Members\Pages;

use App\Filament\Resources\Members\MembersResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMembers extends CreateRecord
{
    protected static string $resource = MembersResource::class;

    protected function getRedirectUrl(): string
    {
        return route('members.index');
    }
}
