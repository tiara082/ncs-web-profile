<?php

namespace App\Filament\Resources\Archives\Schemas;

use Filament\Schemas\Schema;

class ArchivesForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
