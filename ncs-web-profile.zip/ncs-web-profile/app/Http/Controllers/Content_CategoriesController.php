<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Content_CategoriesController extends Controller
{
    //
    
}
